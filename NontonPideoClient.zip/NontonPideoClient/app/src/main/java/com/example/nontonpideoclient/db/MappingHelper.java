package com.example.nontonpideoclient.db;

import android.database.Cursor;

import com.example.nontonpideoclient.entity.Video;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.OVERVIEW;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.PICTURE;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.SCORE;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.TITLE;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.YEAR;


public class MappingHelper {

    public static ArrayList<Video> mapCursorToMoviesArrayList(Cursor cursor) {
        ArrayList<Video> videosList = new ArrayList<>();
        while (cursor.moveToNext()) {
            Video video = getVideoFromCursor(cursor);
            video.setType(Video.MOVIE);
            videosList.add(video);
        }
        return videosList;
    }

    public static ArrayList<Video> mapCursorToTVShowsArrayList(Cursor cursor) {
        ArrayList<Video> videosList = new ArrayList<>();
        while (cursor.moveToNext()) {
            Video video = getVideoFromCursor(cursor);
            video.setType(Video.TV_SHOW);
            videosList.add(video);
        }
        return videosList;
    }

    private static Video getVideoFromCursor(Cursor cursor){
        Video video;
        int id = cursor.getInt(cursor.getColumnIndexOrThrow(_ID));
        String title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE));
        String overview = cursor.getString(cursor.getColumnIndexOrThrow(OVERVIEW));
        String year = cursor.getString(cursor.getColumnIndexOrThrow(YEAR));
        String score = cursor.getString(cursor.getColumnIndexOrThrow(SCORE));
        String picture = cursor.getString(cursor.getColumnIndexOrThrow(PICTURE));

        video = new Video(id, title, picture, year, overview, score);
        return video;
    }

}
