package com.example.nontonpideoclient.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.nontonpideoclient.R;
import com.example.nontonpideoclient.entity.Video;

import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {

    private Context context;
    private ArrayList<Video> videos = new ArrayList<>();

    public VideoAdapter(Context context) {
        this.context = context;
    }

    private ArrayList<Video> getVideos() {
        return videos;
    }

    public void setVideos(ArrayList<Video> videos) {
        this.videos = videos;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemRow = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_video,
                viewGroup, false);
        return new VideoViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder cvh, int i) {
        cvh.bindVideoData(getVideos().get(i));
    }

    @Override
    public int getItemCount() {
        return getVideos().size();
    }

    class VideoViewHolder extends RecyclerView.ViewHolder {

        ImageView poster;
        TextView title;
        TextView year;
        TextView overview;

        VideoViewHolder(@NonNull View v) {
            super(v);
            poster = v.findViewById(R.id.img_poster);
            title = v.findViewById(R.id.tv_title);
            year = v.findViewById(R.id.tv_year);
            overview = v.findViewById(R.id.tv_overview);
        }
        void bindVideoData(Video video){
            this.title.setText(getShortTitle(video.getTitle()));
            this.year.setText(video.getYear());
            this.overview.setText(getShortOverview(video.getOverview()));
            Glide.with(context).load(video.getPicture()).into(this.poster);
        }
    }

    private String getShortOverview(String overview) {
        if (overview.length() > 100) {
            overview = overview.substring(0, 99);
            overview = String.format("%s...", overview);
        } else if (overview.length() < 100) {
            overview = String.format("%-100s", overview);
        }
        return overview;
    }

    private String getShortTitle(String title){
        if (title.length() > 20) {
            title = title.substring(0, 19);
            title = String.format("%s...", title);
        } else if (title.length() < 20) {
            title = String.format("%-20s", title);
        }
        return title;
    }
}
