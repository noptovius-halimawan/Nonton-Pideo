package com.example.nontonpideoclient.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import com.example.nontonpideoclient.R;
import com.example.nontonpideoclient.adapter.MyPagerAdapter;

public class MainActivity extends AppCompatActivity implements TabLayout.OnTabSelectedListener{

    public static final String MY_SHARED_PREFERENCES = "MySharedPrefs";
    public static final String VIEW_MODE_KEY = "VIEW_MODE_KEY";
    public static final String HOME_MODE = "HOME_MODE";
    public static final int MOVIE_INDEX = 0;
    public static final int TV_SHOW_INDEX = 1;
    public static boolean IS_LOADING;
    static ProgressBar PROGRESS_BAR;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private ViewPager viewPager;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeSharedPreferences();
        initializeTabs();
        initializeViews();
        showLoading();
    }

    private void initializeViews() {
        PROGRESS_BAR = findViewById(R.id.main_progress_bar);
    }

    private void initializeSharedPreferences() {
        preferences = getSharedPreferences(MY_SHARED_PREFERENCES, Context.MODE_PRIVATE);
        editor = preferences.edit();
        editor.putString(VIEW_MODE_KEY, HOME_MODE);
        editor.commit();
    }

    private void initializeTabs() {
        viewPager = findViewById(R.id.main_view_pager);
        tabLayout = findViewById(R.id.tab_layout);

        MyPagerAdapter pagerAdapter = new MyPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(this);
    }

    static synchronized void showLoading() {
        IS_LOADING = true;
        if (PROGRESS_BAR == null)
            return;
        PROGRESS_BAR.setVisibility(View.VISIBLE);
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        int pos = tab.getPosition();
        viewPager.setCurrentItem(pos);
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }
}
