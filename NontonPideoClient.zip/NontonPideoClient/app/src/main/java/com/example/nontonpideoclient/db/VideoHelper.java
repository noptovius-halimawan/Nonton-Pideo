package com.example.nontonpideoclient.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.util.Log;

import com.example.nontonpideoclient.entity.Video;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.CONTENT_URI;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.OVERVIEW;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.PICTURE;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.SCORE;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.TABLE_FAVORITE_MOVIE;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.TABLE_FAVORITE_TV_SHOWS;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.TITLE;
import static com.example.nontonpideoclient.db.DatabaseContract.FavoriteColumns.YEAR;


public class VideoHelper {
    private static final String DATABASE_MOVIES_TABLE = TABLE_FAVORITE_MOVIE;
    private static final String DATABASE_TV_SHOWS_TABLE = TABLE_FAVORITE_TV_SHOWS;
    private static DatabaseHelper databaseHelper;
    private static VideoHelper INSTANCE;
    private static SQLiteDatabase database;
    private Context context;

    private VideoHelper(Context context) {
        databaseHelper = new DatabaseHelper(context);
        this.context = context;
    }

    public static VideoHelper getInstance(Context context){
        if (INSTANCE == null) {
            synchronized (SQLiteOpenHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new VideoHelper(context);
                }
            }
        }
        return INSTANCE;
    }

    public void open() throws SQLException {
        database = databaseHelper.getWritableDatabase();
    }

    public void close() {
        if(databaseHelper != null)
            databaseHelper.close();

        if (database != null && database.isOpen()) {
            database.close();
        }
    }

    public ArrayList<Video> getFavoriteMoviesData() {
        ArrayList<Video> videos = new ArrayList<>();
        Video video;
        Cursor cursor = getMoviesViewCursor();
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            do {
                video = getMovieFromCursor(cursor);
                videos.add(video);
                cursor.moveToNext();
            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return videos;
    }

    public ArrayList<Video> getFavoriteTVShowsData() {
        ArrayList<Video> videos = new ArrayList<>();
        Video video;

        Cursor cursor = getTVShowsViewCursor();
        cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            do {
                video = getTVShowFromCursor(cursor);
                videos.add(video);
                cursor.moveToNext();
            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return videos;
    }

    Cursor getMoviesViewCursor() {
        try{
            return context.getContentResolver().query(Uri.parse(CONTENT_URI + "/" + TABLE_FAVORITE_MOVIE),
                    null, null, null, null);
        }catch(Exception e){
            Log.e("debug", "Getmoviesviewcursor broke: " + e);
            return null;
        }
    }

    Cursor getTVShowsViewCursor() {
        return context.getContentResolver().query(Uri.parse(CONTENT_URI + "/" + TABLE_FAVORITE_TV_SHOWS),
                null, null, null, null);
    }

    public boolean getMovieFavoritedStatus(int id) {
        Video video = null;
        Cursor cursor = getMoviesSearchCursor(id);

        cursor.moveToFirst();
        video = getMovieFromCursor(cursor);
        cursor.close();

        return video != null;
    }

    public boolean getTVShowFavoritedStatus(int id) {
        Video video = null;
        Cursor cursor = getTVShowsSearchCursor(id);

        cursor.moveToFirst();
        video = getMovieFromCursor(cursor);
        cursor.close();

        return video != null;
    }

    private Video getMovieFromCursor(Cursor cursor) {
        Video video = null;

        if(cursor.getCount() > 0){
            video = new Video(
                    Video.MOVIE,
                    cursor.getInt(cursor.getColumnIndexOrThrow(_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(TITLE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(PICTURE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(YEAR)),
                    cursor.getString(cursor.getColumnIndexOrThrow(OVERVIEW)),
                    cursor.getString(cursor.getColumnIndexOrThrow(SCORE))
            );
        }
        return video;
    }

    private Video getTVShowFromCursor(Cursor cursor) {
        Video video = null;

        if(cursor.getCount() > 0){
            video = new Video(
                    Video.TV_SHOW,
                    cursor.getInt(cursor.getColumnIndexOrThrow(_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(TITLE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(PICTURE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(YEAR)),
                    cursor.getString(cursor.getColumnIndexOrThrow(OVERVIEW)),
                    cursor.getString(cursor.getColumnIndexOrThrow(SCORE))
            );
        }
        return video;
    }

    Cursor getMoviesSearchCursor(int id) {
        return context.getContentResolver().query(Uri.parse(CONTENT_URI + "/"
                        + TABLE_FAVORITE_MOVIE + "/" + id),null, null, null,
                null);
    }

    Cursor getTVShowsSearchCursor(int id) {
        return context.getContentResolver().query(Uri.parse(CONTENT_URI + "/"
                + TABLE_FAVORITE_TV_SHOWS + "/" + id),null, null, null,
                null);
    }

    public Uri insertMovie(Video video) {
        return context.getContentResolver().insert(Uri.parse(CONTENT_URI + "/"
                + TABLE_FAVORITE_MOVIE), getContentFromVideo(video));
    }

    public Uri insertTVShow(Video video) {
        return context.getContentResolver().insert(Uri.parse(CONTENT_URI + "/"
                + TABLE_FAVORITE_TV_SHOWS), getContentFromVideo(video));
    }

    public ContentValues getContentFromVideo(Video video) {
        ContentValues args = new ContentValues();
        args.put(_ID, video.getId());
        args.put(TITLE, video.getTitle());
        args.put(PICTURE, video.getPicture());
        args.put(YEAR, video.getYear());
        args.put(OVERVIEW, video.getOverview());
        args.put(SCORE, video.getScore());
        return args;
    }

    public int deleteMovie(int id) {
        return context.getContentResolver().delete(Uri.parse(CONTENT_URI + "/"
                + TABLE_FAVORITE_MOVIE + "/" + id),_ID + " = ?", new String[]{
                        String.valueOf(id)});
    }

    public int deleteTVShow(int id) {
        return context.getContentResolver().delete(Uri.parse(CONTENT_URI + "/"
                + TABLE_FAVORITE_TV_SHOWS + "/" + id),_ID + " = ?", new String[]{
                String.valueOf(id)});
    }

    public Cursor queryByIdMovieProvider(String id){
        return database.query(DATABASE_MOVIES_TABLE, null, _ID + " = ?",
                new String[]{id}, null, null, null, null);
    }

    public Cursor queryByIdTVShowProvider(String id){
        return database.query(DATABASE_TV_SHOWS_TABLE, null, _ID + " = ?",
                new String[]{id}, null, null, null, null);
    }

    public Cursor queryMovieProvider(){
        return database.query(DATABASE_MOVIES_TABLE, null, null, null,
                null, null, _ID + " ASC");
    }

    public Cursor queryTVShowProvider(){
        return database.query(DATABASE_TV_SHOWS_TABLE, null, null, null,
                null, null, _ID + " ASC");
    }

    public long insertMovieProvider(ContentValues values) {
        return database.insert(DATABASE_MOVIES_TABLE, null, values);
    }

    public long insertTVShowProvider(ContentValues values) {
        return database.insert(DATABASE_TV_SHOWS_TABLE, null, values);
    }

    public int updateMovieProvider(String id, ContentValues values) {
        return database.update(DATABASE_MOVIES_TABLE, values, _ID + " = ?", new String[]{id});
    }

    public int updateTVShowProvider(String id, ContentValues values) {
        return database.update(DATABASE_TV_SHOWS_TABLE, values, _ID + " = ?", new String[]{id});
    }

    public int deleteMovieProvider(String id) {
        return database.delete(DATABASE_MOVIES_TABLE, _ID + " = ?", new String[]{id});
    }

    public int deleteTVShowProvider(String id) {
        return database.delete(DATABASE_TV_SHOWS_TABLE, _ID + " = ?", new String[]{id});
    }
}
