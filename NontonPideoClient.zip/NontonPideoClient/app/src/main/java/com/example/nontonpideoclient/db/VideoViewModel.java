package com.example.nontonpideoclient.db;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Context;
import android.util.Log;

import com.example.nontonpideoclient.entity.Video;

import java.util.ArrayList;

public class VideoViewModel extends ViewModel {
    private static final String TAG = "VideoViewModel";

    private MutableLiveData<ArrayList<Video>> upcomingMoviesLiveData = new MutableLiveData<>();
    private MutableLiveData<ArrayList<Video>> popularTVShowLiveData = new MutableLiveData<>();
    private VideoHelper videoHelper;

    public LiveData<ArrayList<Video>> getUpcomingMoviesLiveData() {
        return upcomingMoviesLiveData;
    }

    public LiveData<ArrayList<Video>> getPopularTVShowLiveData() {
        return popularTVShowLiveData;
    }

    public VideoViewModel() {
    }

    public void getAndInsertFavoriteMoviesToLiveData(Context context){
        ArrayList<Video> videos;

        videoHelper = VideoHelper.getInstance(context);
        videoHelper.open();

        videos = videoHelper.getFavoriteMoviesData();
        Log.d("debug", "video arraylist size: " + videos.size());
        upcomingMoviesLiveData.postValue(videos);
    }

    public void getAndInsertFavoriteTVShowsToLiveData(Context context){
        ArrayList<Video> videos;

        videoHelper = VideoHelper.getInstance(context);
        videoHelper.open();

        videos = videoHelper.getFavoriteTVShowsData();
        popularTVShowLiveData.postValue(videos);
    }
}
